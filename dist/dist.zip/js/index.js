$(document).ready( () => {
  console.log('test');
});
